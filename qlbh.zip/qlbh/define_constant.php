<?php
/************ Database ************/

define('CMS_DB_HOST', 'localhost');
define('CMS_DB_USER', 'root');
define('CMS_DB_PASSWORD', '');
define('CMS_DB_NAME', 'pos_new_7');
define('CMS_DB_PREFIX', 'cms_');

/************ ORTHER ************/
define('CMS_BASE_URL', '');
define('CMS_DEFAULT_LANGUAGE', 'vietnamese');
define('CMS_PREFIX', md5('CMS_'));
define('COOKIE_EXPIRY', 60480);